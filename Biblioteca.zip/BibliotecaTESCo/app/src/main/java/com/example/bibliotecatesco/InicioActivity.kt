package com.example.bibliotecatesco

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class InicioActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inicio)

        val botonCatalogo = findViewById<Button>(R.id.btnCatalogo)
        botonCatalogo.setOnClickListener {
            startActivity(Intent(this, CatalogoActivity::class.java))
        }
        val botonBuscar = findViewById<Button>(R.id.btnBuscar)
        botonBuscar.setOnClickListener {
            startActivity(Intent(this, BuscarActivity::class.java))
        }
        val btnFavoritos = findViewById<Button>(R.id.btnFavoritos)
        btnFavoritos.setOnClickListener {
            val intent = Intent(this, FavoritosActivity::class.java)
            startActivity(intent)
        }
        val botonPerfil = findViewById<Button>(R.id.btnPerfil)
        botonPerfil.setOnClickListener {
            startActivity(Intent(this, PerfilActivity::class.java))
        }
        val btnCerrarSesion = findViewById<Button>(R.id.btnCerrarSesion)
        btnCerrarSesion.setOnClickListener {
            // Aquí puedes agregar lógica adicional como limpiar datos de sesión, etc.
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish() // Cierra la pantalla actual
        }

    }
}
